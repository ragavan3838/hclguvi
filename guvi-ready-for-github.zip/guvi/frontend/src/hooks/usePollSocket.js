import { useState, useEffect, useRef, useCallback } from 'react';
import { sendReaction } from '../services/api';

export function usePollSocket(pollId) {
  const [isConnected, setIsConnected] = useState(false);
  const [liveVotes, setLiveVotes] = useState({});
  const [totalVotes, setTotalVotes] = useState(0);
  const [totalVoters, setTotalVoters] = useState(0);
  const [viewersCount, setViewersCount] = useState(1);
  const [isClosed, setIsClosed] = useState(false);
  const [reactions, setReactions] = useState([]);

  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const isMountedRef = useRef(true);

  const setInitialState = useCallback((poll) => {
    if (!poll) return;
    const initialMap = {};
    (poll.options || []).forEach(opt => {
      initialMap[opt.id] = opt.voteCount || 0;
    });
    setLiveVotes(initialMap);
    setTotalVotes(poll.totalVotes || 0);
    setTotalVoters(poll.totalVoters || 0);
    setIsClosed(!!poll.isClosed);
  }, []);

  const addReaction = useCallback((emoji) => {
    const id = 'react_' + Math.random().toString(36).substring(2, 9) + Date.now();
    const xOffset = (Math.random() - 0.5) * 160; // Random spread
    setReactions(prev => [...prev.slice(-15), { id, emoji, xOffset }]);

    setTimeout(() => {
      setReactions(prev => prev.filter(r => r.id !== id));
    }, 2200);
  }, []);

  const connect = useCallback(() => {
    if (!pollId) return;

    // Use current host for websocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    // When in dev, connect directly to port 8080 or through Vite proxy
    const host = window.location.port === '5173' ? 'localhost:8080' : window.location.host;
    const wsUrl = `${protocol}//${host}/ws/poll/${pollId}`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!isMountedRef.current) return;
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          switch (msg.type) {
            case 'vote_update':
              if (msg.data) {
                setLiveVotes(msg.data.votes || {});
                setTotalVotes(msg.data.totalVotes || 0);
                setTotalVoters(msg.data.totalVoters || 0);
              }
              break;

            case 'reaction':
              if (msg.data && msg.data.emoji) {
                addReaction(msg.data.emoji);
              }
              break;

            case 'viewers_update':
              if (msg.data && typeof msg.data.count === 'number') {
                setViewersCount(msg.data.count);
              }
              break;

            case 'state_change':
              if (msg.data && typeof msg.data.isClosed === 'boolean') {
                setIsClosed(msg.data.isClosed);
              }
              break;

            default:
              break;
          }
        } catch (e) {
          console.error('[WebSocket] Message parsing error:', e);
        }
      };

      ws.onclose = () => {
        if (!isMountedRef.current) return;
        setIsConnected(false);
        // Attempt reconnect in 2 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          if (isMountedRef.current) {
            connect();
          }
        }, 2000);
      };

      ws.onerror = (err) => {
        console.warn('[WebSocket] Connection error:', err);
        ws.close();
      };
    } catch (err) {
      console.error('[WebSocket] Init failed:', err);
    }
  }, [pollId, addReaction]);

  useEffect(() => {
    isMountedRef.current = true;
    connect();

    return () => {
      isMountedRef.current = false;
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  const triggerReaction = useCallback(async (emoji) => {
    // Show locally immediately for responsiveness
    addReaction(emoji);

    // Send through WebSocket if open, else REST fallback
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      try {
        wsRef.current.send(JSON.stringify({ type: 'reaction', emoji }));
        return;
      } catch (e) {
        console.warn('WS send failed, using REST:', e);
      }
    }
    await sendReaction(pollId, emoji);
  }, [pollId, addReaction]);

  return {
    isConnected,
    liveVotes,
    totalVotes,
    totalVoters,
    viewersCount,
    isClosed,
    reactions,
    triggerReaction,
    setInitialState,
  };
}
