import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Crown, Users, Radio, Maximize2, Minimize2, Sparkles } from 'lucide-react';
import { getPoll } from '../services/api';
import { usePollSocket } from '../hooks/usePollSocket';
import LiveBadge from '../components/LiveBadge';
import ReactionOverlay from '../components/ReactionOverlay';

export default function PresentationMode({ pollId, onExit }) {
  const [poll, setPoll] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const {
    isConnected,
    liveVotes,
    totalVotes,
    totalVoters,
    viewersCount,
    isClosed,
    reactions,
    setInitialState,
  } = usePollSocket(pollId);

  useEffect(() => {
    async function load() {
      try {
        const data = await getPoll(pollId);
        setPoll(data.poll);
        setInitialState(data.poll);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [pollId, setInitialState]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onExit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onExit]);

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
      }
    }
  };

  if (loading || !poll) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950 text-white">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent" />
      </div>
    );
  }

  const voteUrl = `${window.location.origin}/#poll=${poll.id}`;

  let maxVotes = 0;
  poll.options.forEach(opt => {
    const count = liveVotes[opt.id] ?? opt.voteCount ?? 0;
    if (count > maxVotes) maxVotes = count;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950 text-slate-100 flex flex-col justify-between p-6 sm:p-12 selection:bg-indigo-500">
      <ReactionOverlay reactions={reactions} />

      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 shadow-lg shadow-indigo-600/30">
            <Radio className="h-5 w-5 text-white animate-pulse" />
          </div>
          <div>
            <span className="text-xl font-black text-white tracking-tight">Pulse<span className="text-indigo-400">Poll</span></span>
            <span className="ml-2 text-xs font-semibold text-slate-400 font-mono">PROJECTOR MODE</span>
          </div>
          <LiveBadge 
            isConnected={isConnected} 
            viewersCount={viewersCount} 
            isClosed={isClosed} 
          />
        </div>

        {/* Presentation Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleFullScreen}
            className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900/80 px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
          >
            {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            <span className="hidden sm:inline">{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
          </button>

          <button
            onClick={onExit}
            className="flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 px-3.5 py-2 text-xs font-bold text-white transition-colors"
          >
            <X className="h-4 w-4" />
            <span>Close (Esc)</span>
          </button>
        </div>
      </div>

      {/* Main Center Presentation View */}
      <div className="my-auto py-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center max-w-7xl mx-auto w-full">
        
        {/* Left Side: Poll Question and Live Bars */}
        <div className="lg:col-span-8 space-y-8">
          <div>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight">
              {poll.title}
            </h1>
            {poll.description && (
              <p className="mt-3 text-lg text-slate-400">
                {poll.description}
              </p>
            )}
          </div>

          <div className="space-y-4">
            {poll.options.map((opt) => {
              const count = liveVotes[opt.id] ?? opt.voteCount ?? 0;
              const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
              const isLeader = maxVotes > 0 && count === maxVotes;

              return (
                <div
                  key={opt.id}
                  className={`relative overflow-hidden rounded-2xl border transition-all duration-500 ${
                    isLeader && totalVotes > 0
                      ? 'border-indigo-500 bg-slate-900 shadow-2xl shadow-indigo-500/20'
                      : 'border-slate-800/80 bg-slate-900/60'
                  }`}
                >
                  {/* Fill Bar */}
                  <div
                    className="absolute inset-y-0 left-0 transition-all duration-700 ease-out"
                    style={{
                      width: `${pct}%`,
                      backgroundColor: opt.color || '#6366F1',
                      opacity: isLeader && totalVotes > 0 ? 0.35 : 0.2,
                    }}
                  />

                  <div className="relative flex items-center justify-between p-5 sm:p-6">
                    <div className="flex items-center gap-4">
                      <span className="text-3xl sm:text-4xl">{opt.emoji || '⚡'}</span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-lg sm:text-2xl font-bold text-white">
                            {opt.text}
                          </span>
                          {isLeader && totalVotes > 0 && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/20 border border-amber-400/40 px-2.5 py-0.5 text-xs font-black text-amber-300">
                              <Crown className="h-3.5 w-3.5" /> LEADER
                            </span>
                          )}
                        </div>
                        <span className="text-sm font-mono text-slate-400">
                          {count} {count === 1 ? 'vote' : 'votes'}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-3xl sm:text-5xl font-black font-mono text-white tracking-tight">
                        {pct}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: QR Code for Audience to Scan and Join */}
        <div className="lg:col-span-4 flex flex-col items-center justify-center">
          <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-8 shadow-2xl text-center backdrop-blur-xl w-full max-w-sm">
            <div className="mb-4">
              <span className="inline-block rounded-full bg-indigo-500/15 border border-indigo-500/30 px-3 py-1 text-xs font-bold text-indigo-400">
                JOIN FROM YOUR PHONE
              </span>
            </div>

            {/* QR Code */}
            <div className="mx-auto rounded-2xl bg-white p-5 shadow-lg inline-block">
              <QRCodeSVG
                value={voteUrl}
                size={220}
                level="H"
                includeMargin={true}
              />
            </div>

            <div className="mt-5 space-y-1">
              <p className="text-xs font-semibold text-slate-300">
                Point camera to vote instantly
              </p>
              <p className="text-[11px] font-mono text-indigo-400 truncate px-2">
                {window.location.host}
              </p>
            </div>

            {/* Live Stats Box */}
            <div className="mt-6 border-t border-slate-800 pt-4 flex justify-around text-center">
              <div>
                <div className="text-2xl font-black font-mono text-white">{totalVotes}</div>
                <div className="text-[10px] uppercase font-bold text-slate-500">Votes</div>
              </div>
              <div className="h-8 w-px bg-slate-800 my-auto" />
              <div>
                <div className="text-2xl font-black font-mono text-indigo-400">{viewersCount}</div>
                <div className="text-[10px] uppercase font-bold text-slate-500">Watching</div>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Bottom Footer Info */}
      <div className="flex items-center justify-between text-xs text-slate-500 font-mono border-t border-slate-900 pt-4">
        <div>Poll ID: <span className="text-slate-400">{poll.id}</span></div>
        <div className="flex items-center gap-1">
          <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
          <span>Real-time Redis Counters &amp; Pub/Sub Broadcasting</span>
        </div>
      </div>

    </div>
  );
}
