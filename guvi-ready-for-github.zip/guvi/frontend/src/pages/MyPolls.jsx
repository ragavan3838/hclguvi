import React, { useState, useEffect } from 'react';
import { History, BarChart3, Vote, PlusCircle, ExternalLink, Trash2, Calendar, Radio } from 'lucide-react';
import { getSavedPolls } from '../services/api';

export default function MyPolls({ onSelectPoll, onVotePoll, onCreateNew }) {
  const [polls, setPolls] = useState([]);

  useEffect(() => {
    setPolls(getSavedPolls());
  }, []);

  const handleDelete = (id, e) => {
    e.stopPropagation();
    const updated = polls.filter(p => p.id !== id);
    setPolls(updated);
    localStorage.setItem('pulsepoll_created_polls', JSON.stringify(updated));
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      
      <div className="mb-8 sm:flex sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            My Created Polls
          </h1>
          <p className="mt-2 text-sm text-slate-400">
            Access, present, or manage polls launched from this device.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="mt-4 sm:mt-0 flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-all active:scale-95"
        >
          <PlusCircle className="h-4 w-4" />
          <span>New Poll</span>
        </button>
      </div>

      {polls.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-800 bg-slate-900/30 p-12 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-500/10 text-indigo-400">
            <Radio className="h-7 w-7" />
          </div>
          <h3 className="text-lg font-bold text-white">No Polls Created Yet</h3>
          <p className="mt-1 text-sm text-slate-400 max-w-sm mx-auto">
            You haven't launched any polls on this browser. Create your first live poll in just 30 seconds!
          </p>
          <button
            onClick={onCreateNew}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white hover:bg-indigo-500 transition-colors"
          >
            <PlusCircle className="h-4 w-4" />
            <span>Create Poll Now</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {polls.map((poll) => (
            <div
              key={poll.id}
              onClick={() => onSelectPoll(poll.id)}
              className="group relative rounded-2xl border border-slate-800/80 bg-slate-900/60 p-6 backdrop-blur-md transition-all hover:border-slate-700 hover:bg-slate-900/90 hover:shadow-xl cursor-pointer"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-indigo-500/20 px-2 py-0.5 text-[10px] font-mono text-indigo-300 border border-indigo-500/30">
                      ID: {poll.id}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] text-slate-500 font-mono">
                      <Calendar className="h-3 w-3" />
                      {new Date(poll.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h3 className="mt-3 text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-2">
                    {poll.title}
                  </h3>
                </div>

                <button
                  onClick={(e) => handleDelete(poll.id, e)}
                  className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-800 hover:text-rose-400 transition-colors"
                  title="Remove from history"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              {/* Action Links */}
              <div className="mt-6 flex items-center justify-between border-t border-slate-800/60 pt-4 text-xs font-semibold">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onVotePoll(poll.id);
                  }}
                  className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors"
                >
                  <Vote className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Vote Link</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectPoll(poll.id);
                  }}
                  className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  <BarChart3 className="h-3.5 w-3.5" />
                  <span>Live Results &rarr;</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}
