const API_BASE = '/api';

export function getVoterId() {
  let voterId = localStorage.getItem('pulsepoll_voter_id');
  if (!voterId) {
    voterId = 'v_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
    localStorage.setItem('pulsepoll_voter_id', voterId);
  }
  return voterId;
}

export function getSavedPolls() {
  try {
    const raw = localStorage.getItem('pulsepoll_created_polls');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveCreatedPoll(poll, creatorToken) {
  const polls = getSavedPolls();
  const entry = {
    id: poll.id,
    title: poll.title,
    createdAt: poll.createdAt || new Date().toISOString(),
    creatorToken: creatorToken,
    optionsCount: poll.options?.length || 0,
  };
  const filtered = polls.filter(p => p.id !== poll.id);
  filtered.unshift(entry);
  localStorage.setItem('pulsepoll_created_polls', JSON.stringify(filtered.slice(0, 30)));
}

export function getLocalVote(pollId) {
  try {
    const raw = localStorage.getItem(`pulsepoll_voted_${pollId}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function recordLocalVote(pollId, optionIds) {
  localStorage.setItem(`pulsepoll_voted_${pollId}`, JSON.stringify({
    optionIds,
    timestamp: Date.now()
  }));
}

export async function fetchHealth() {
  const res = await fetch(`${API_BASE}/health`);
  return res.json();
}

export async function createPoll(payload) {
  const res = await fetch(`${API_BASE}/polls`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to create poll' }));
    throw new Error(err.error || 'Failed to create poll');
  }
  return res.json();
}

export async function getPoll(id, creatorToken = '') {
  const headers = {};
  if (creatorToken) {
    headers['X-Creator-Token'] = creatorToken;
  }
  const res = await fetch(`${API_BASE}/polls/${id}`, { headers });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to fetch poll' }));
    throw new Error(err.error || 'Failed to fetch poll');
  }
  return res.json();
}

export async function submitVote(id, { optionIds, voterName }) {
  const voterId = getVoterId();
  const res = await fetch(`${API_BASE}/polls/${id}/vote`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      voterId,
      voterName,
      optionIds,
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to submit vote' }));
    throw new Error(err.error || 'Failed to submit vote');
  }
  return res.json();
}

export async function sendReaction(id, emoji) {
  const res = await fetch(`${API_BASE}/polls/${id}/reaction`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ emoji }),
  });
  return res.ok;
}

export async function togglePollState(id, { creatorToken, isClosed }) {
  const res = await fetch(`${API_BASE}/polls/${id}/state`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ creatorToken, isClosed }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to toggle state' }));
    throw new Error(err.error || 'Failed to toggle state');
  }
  return res.json();
}

export async function resetPoll(id, creatorToken) {
  const res = await fetch(`${API_BASE}/polls/${id}/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ creatorToken }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to reset poll' }));
    throw new Error(err.error || 'Failed to reset poll');
  }
  return res.json();
}

export async function exportVotes(id, creatorToken) {
  const res = await fetch(`${API_BASE}/polls/${id}/export?token=${encodeURIComponent(creatorToken)}`);
  if (!res.ok) {
    throw new Error('Failed to export votes');
  }
  return res.json();
}
