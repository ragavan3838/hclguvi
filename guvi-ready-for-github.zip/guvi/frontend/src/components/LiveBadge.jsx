import React from 'react';
import { Users, Wifi, WifiOff } from 'lucide-react';

export default function LiveBadge({ isConnected, viewersCount, isClosed }) {
  if (isClosed) {
    return (
      <div className="inline-flex items-center gap-2 rounded-full border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-400">
        <span className="h-2 w-2 rounded-full bg-rose-500"></span>
        <span>POLL CLOSED</span>
      </div>
    );
  }

  return (
    <div className="inline-flex items-center gap-3 rounded-full border border-slate-800 bg-slate-900/90 px-3.5 py-1 text-xs backdrop-blur-md">
      {/* Live Pulsing Dot */}
      <div className="flex items-center gap-1.5 font-semibold">
        <span className="relative flex h-2.5 w-2.5">
          {isConnected && (
            <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping"></span>
          )}
          <span className={`relative inline-flex h-2.5 w-2.5 rounded-full ${isConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
        </span>
        <span className={isConnected ? 'text-emerald-400 tracking-wider' : 'text-amber-400'}>
          {isConnected ? 'LIVE' : 'CONNECTING...'}
        </span>
      </div>

      <div className="h-3 w-px bg-slate-700/60" />

      {/* Live Viewers Count */}
      <div className="flex items-center gap-1.5 text-slate-300 font-medium font-mono text-[11px]">
        <Users className="h-3.5 w-3.5 text-indigo-400" />
        <span>{viewersCount} {viewersCount === 1 ? 'watching' : 'watching'}</span>
      </div>
    </div>
  );
}
