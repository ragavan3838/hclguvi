import React, { useState, useEffect } from 'react';
import { Radio, PlusCircle, History, Activity, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { fetchHealth } from '../services/api';

export default function Navbar({ currentView, setView }) {
  const [health, setHealth] = useState(null);
  const [showHealthTooltip, setShowHealthTooltip] = useState(false);

  useEffect(() => {
    fetchHealth()
      .then(setHealth)
      .catch(() => setHealth({ status: 'offline' }));

    const interval = setInterval(() => {
      fetchHealth()
        .then(setHealth)
        .catch(() => setHealth({ status: 'offline' }));
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const isHealthy = health?.mongodb === 'connected' && health?.redis === 'connected';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Brand Logo */}
        <div 
          onClick={() => setView('create')}
          className="flex cursor-pointer items-center gap-2.5 transition-transform hover:scale-105"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 shadow-lg shadow-indigo-500/25">
            <Radio className="h-5 w-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black tracking-tight text-white">Pulse<span className="text-indigo-400">Poll</span></span>
              <span className="rounded-full bg-indigo-500/20 px-2 py-0.5 text-[10px] font-semibold text-indigo-300 border border-indigo-500/30">LIVE</span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium hidden sm:block">Real-time Redis & Go Engine</p>
          </div>
        </div>

        {/* Center / Navigation items */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setView('create')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition-all ${
              currentView === 'create'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <PlusCircle className="h-4 w-4" />
            <span>Create Poll</span>
          </button>

          <button
            onClick={() => setView('my-polls')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition-all ${
              currentView === 'my-polls'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
            }`}
          >
            <History className="h-4 w-4" />
            <span>My Polls</span>
          </button>
        </nav>

        {/* Stack Health Status Indicator */}
        <div className="relative">
          <button
            onClick={() => setShowHealthTooltip(!showHealthTooltip)}
            onMouseEnter={() => setShowHealthTooltip(true)}
            onMouseLeave={() => setShowHealthTooltip(false)}
            className="flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900/90 px-3 py-1.5 text-xs text-slate-300 hover:border-slate-700 transition-colors"
          >
            <span className="relative flex h-2 w-2">
              <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${isHealthy ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
              <span className={`relative inline-flex h-2 w-2 rounded-full ${isHealthy ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </span>
            <span className="hidden md:inline font-mono text-[11px]">Stack Active</span>
            <Activity className="h-3.5 w-3.5 text-slate-400" />
          </button>

          {/* Health Details Tooltip Popover */}
          {showHealthTooltip && (
            <div className="absolute right-0 mt-2 w-64 rounded-xl border border-slate-800 bg-slate-900/95 p-3.5 shadow-2xl backdrop-blur-md z-50 text-xs text-slate-300 animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                <span className="font-semibold text-white">System Health</span>
                <span className="text-[10px] text-slate-400 font-mono">Live Check</span>
              </div>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Redis (Realtime):</span>
                  <span className="flex items-center gap-1 text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" />
                    {health?.redis || 'checking...'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">MongoDB (Store):</span>
                  <span className="flex items-center gap-1 text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" />
                    {health?.mongodb || 'checking...'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Go Backend (Gin):</span>
                  <span className="flex items-center gap-1 text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" />
                    healthy
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </header>
  );
}
