import React from 'react';

export default function ReactionOverlay({ reactions = [] }) {
  if (!reactions || reactions.length === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {reactions.map((r) => (
        <div
          key={r.id}
          className="animate-float-up absolute bottom-24 left-1/2 text-4xl select-none"
          style={{
            '--tw-float-x': `${r.xOffset || 0}px`,
          }}
        >
          {r.emoji}
        </div>
      ))}
    </div>
  );
}
