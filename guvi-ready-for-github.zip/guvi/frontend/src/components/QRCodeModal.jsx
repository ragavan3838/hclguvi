import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Copy, Check, ExternalLink, Smartphone, Tv } from 'lucide-react';

export default function QRCodeModal({ poll, isOpen, onClose, onOpenPresent }) {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !poll) return null;

  const voteUrl = `${window.location.origin}/#poll=${poll.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(voteUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/10 text-indigo-400">
            <Smartphone className="h-6 w-6" />
          </div>
          <h3 className="text-xl font-bold text-white">Join Live Poll</h3>
          <p className="mt-1 text-xs text-slate-400 line-clamp-2 px-4">
            {poll.title}
          </p>
        </div>

        {/* QR Code Container */}
        <div className="my-6 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-white p-6 shadow-inner">
          <QRCodeSVG
            value={voteUrl}
            size={210}
            level="H"
            includeMargin={true}
          />
          <p className="mt-3 text-xs font-semibold text-slate-600 tracking-wide">
            SCAN WITH PHONE CAMERA TO VOTE
          </p>
        </div>

        {/* Share Link Input */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950 px-3 py-2">
            <input
              type="text"
              readOnly
              value={voteUrl}
              className="w-full bg-transparent text-xs font-mono text-slate-300 focus:outline-none"
            />
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white transition-all hover:bg-indigo-500 active:scale-95"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>

          {/* Action Row */}
          <div className="flex gap-2 pt-1">
            <button
              onClick={() => {
                onClose();
                if (onOpenPresent) onOpenPresent();
              }}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-indigo-500/30 bg-indigo-500/10 py-2.5 text-xs font-semibold text-indigo-300 transition-colors hover:bg-indigo-500/20"
            >
              <Tv className="h-4 w-4" />
              <span>Projector / Presenter View</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
