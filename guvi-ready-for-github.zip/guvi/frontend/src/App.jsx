import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import CreatePoll from './pages/CreatePoll';
import VotePoll from './pages/VotePoll';
import LiveResults from './pages/LiveResults';
import PresentationMode from './pages/PresentationMode';
import MyPolls from './pages/MyPolls';
import QRCodeModal from './components/QRCodeModal';

export default function App() {
  const [view, setView] = useState('create'); // 'create', 'vote', 'results', 'present', 'my-polls'
  const [activePollId, setActivePollId] = useState(null);
  const [createdPollModal, setCreatedPollModal] = useState(null);

  // Parse location hash on mount and hash changes
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#poll=')) {
        const id = hash.replace('#poll=', '').trim();
        if (id) {
          setActivePollId(id);
          setView('vote');
        }
      } else if (hash.startsWith('#results=')) {
        const id = hash.replace('#results=', '').trim();
        if (id) {
          setActivePollId(id);
          setView('results');
        }
      } else if (hash.startsWith('#present=')) {
        const id = hash.replace('#present=', '').trim();
        if (id) {
          setActivePollId(id);
          setView('present');
        }
      } else if (hash === '#my-polls') {
        setView('my-polls');
      } else {
        // Default if no hash
        if (!activePollId) {
          setView('create');
        }
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, [activePollId]);

  const navigateToVote = (pollId) => {
    setActivePollId(pollId);
    window.location.hash = `#poll=${pollId}`;
    setView('vote');
  };

  const navigateToResults = (pollId) => {
    setActivePollId(pollId);
    window.location.hash = `#results=${pollId}`;
    setView('results');
  };

  const navigateToPresent = (pollId) => {
    setActivePollId(pollId);
    window.location.hash = `#present=${pollId}`;
    setView('present');
  };

  const handlePollCreated = (poll, creatorToken) => {
    setActivePollId(poll.id);
    setCreatedPollModal(poll);
    window.location.hash = `#results=${poll.id}`;
    setView('results');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      
      {/* Hide Navbar in fullscreen presentation mode */}
      {view !== 'present' && (
        <Navbar
          currentView={view}
          setView={(newView) => {
            if (newView === 'create') {
              window.location.hash = '';
              setView('create');
            } else if (newView === 'my-polls') {
              window.location.hash = '#my-polls';
              setView('my-polls');
            }
          }}
        />
      )}

      <main className="flex-1">
        {view === 'create' && (
          <CreatePoll onPollCreated={handlePollCreated} />
        )}

        {view === 'vote' && activePollId && (
          <VotePoll
            pollId={activePollId}
            onViewResults={navigateToResults}
          />
        )}

        {view === 'results' && activePollId && (
          <LiveResults
            pollId={activePollId}
            onBackToVote={() => navigateToVote(activePollId)}
            onOpenPresent={navigateToPresent}
          />
        )}

        {view === 'present' && activePollId && (
          <PresentationMode
            pollId={activePollId}
            onExit={() => navigateToResults(activePollId)}
          />
        )}

        {view === 'my-polls' && (
          <MyPolls
            onSelectPoll={navigateToResults}
            onVotePoll={navigateToVote}
            onCreateNew={() => {
              window.location.hash = '';
              setView('create');
            }}
          />
        )}
      </main>

      {/* Share / QR Modal when poll is created */}
      {createdPollModal && (
        <QRCodeModal
          poll={createdPollModal}
          isOpen={Boolean(createdPollModal)}
          onClose={() => setCreatedPollModal(null)}
          onOpenPresent={() => {
            setCreatedPollModal(null);
            navigateToPresent(createdPollModal.id);
          }}
        />
      )}

    </div>
  );
}
