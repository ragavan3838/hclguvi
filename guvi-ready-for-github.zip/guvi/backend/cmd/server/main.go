package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"

	"pulsepoll-backend/internal/config"
	"pulsepoll-backend/internal/database"
	"pulsepoll-backend/internal/handlers"
	"pulsepoll-backend/internal/realtime"
)

func main() {
	cfg := config.LoadConfig()

	log.Println("[PulsePoll] Initializing backend service...")

	// Connect to MongoDB
	mongoDB, err := database.ConnectMongo(cfg.MongoURI, cfg.DatabaseName)
	if err != nil {
		log.Fatalf("[PulsePoll] MongoDB initialization failed: %v", err)
	}
	defer mongoDB.Close()

	// Connect to Redis
	redisClient, err := database.ConnectRedis(cfg.RedisAddr, cfg.RedisPassword)
	if err != nil {
		log.Fatalf("[PulsePoll] Redis initialization failed: %v", err)
	}
	defer redisClient.Close()

	// Initialize Realtime Hub
	hub := realtime.NewHub(redisClient)
	go hub.Run()

	// Handlers
	pollHandler := handlers.NewPollHandler(mongoDB, redisClient, hub)
	wsHandler := handlers.NewWSHandler(hub)

	// Gin Engine Setup
	r := gin.Default()

	// CORS Setup
	corsConfig := cors.DefaultConfig()
	corsConfig.AllowAllOrigins = true
	corsConfig.AllowHeaders = []string{"Origin", "Content-Length", "Content-Type", "X-Creator-Token", "Authorization"}
	corsConfig.AllowMethods = []string{"GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"}
	corsConfig.ExposeHeaders = []string{"Content-Length"}
	corsConfig.AllowCredentials = true
	r.Use(cors.New(corsConfig))

	// API Routes
	api := r.Group("/api")
	{
		api.GET("/health", pollHandler.HealthCheck)
		api.POST("/polls", pollHandler.CreatePoll)
		api.GET("/polls/:id", pollHandler.GetPoll)
		api.POST("/polls/:id/vote", pollHandler.SubmitVote)
		api.POST("/polls/:id/reaction", pollHandler.SendReaction)
		api.PATCH("/polls/:id/state", pollHandler.ToggleState)
		api.POST("/polls/:id/reset", pollHandler.ResetPoll)
		api.GET("/polls/:id/export", pollHandler.ExportVotes)
	}

	// WebSocket Route
	r.GET("/ws/poll/:id", wsHandler.HandlePollWS)

	srv := &http.Server{
		Addr:    ":" + cfg.Port,
		Handler: r,
	}

	// Start server in goroutine
	go func() {
		log.Printf("[PulsePoll] HTTP & WebSocket server listening on port %s", cfg.Port)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("[PulsePoll] Listen failed: %s\n", err)
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("[PulsePoll] Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Fatal("[PulsePoll] Server forced to shutdown:", err)
	}

	log.Println("[PulsePoll] Server exiting")
}
