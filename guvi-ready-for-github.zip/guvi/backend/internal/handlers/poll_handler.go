package handlers

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/big"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"

	"pulsepoll-backend/internal/database"
	"pulsepoll-backend/internal/models"
	"pulsepoll-backend/internal/realtime"
)

type PollHandler struct {
	Mongo *database.MongoDB
	Redis *database.RedisClient
	Hub   *realtime.Hub
}

func NewPollHandler(mongo *database.MongoDB, redis *database.RedisClient, hub *realtime.Hub) *PollHandler {
	return &PollHandler{
		Mongo: mongo,
		Redis: redis,
		Hub:   hub,
	}
}

var defaultColors = []string{
	"#6366F1", // Indigo
	"#EC4899", // Pink
	"#10B981", // Emerald
	"#F59E0B", // Amber
	"#8B5CF6", // Purple
	"#3B82F6", // Blue
	"#14B8A6", // Teal
	"#EF4444", // Red
}

var defaultEmojis = []string{"⚡", "🔥", "🚀", "✨", "🎯", "💡", "🌟", "🎉"}

func generatePollSlug(length int) string {
	const charset = "abcdefghjkmnpqrstuvwxyz23456789"
	b := make([]byte, length)
	for i := range b {
		num, _ := rand.Int(rand.Reader, big.NewInt(int64(len(charset))))
		b[i] = charset[num.Int64()]
	}
	return string(b)
}

// CreatePoll handles creating a new poll
func (h *PollHandler) CreatePoll(c *gin.Context) {
	var req models.CreatePollRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input: " + err.Error()})
		return
	}

	pollID := generatePollSlug(7)
	creatorToken := uuid.New().String()
	now := time.Now().UTC()

	// Assign clean IDs, default colors and emojis if missing
	options := make([]models.Option, len(req.Options))
	for i, opt := range req.Options {
		optID := fmt.Sprintf("opt_%d", i+1)
		color := opt.Color
		if color == "" {
			color = defaultColors[i%len(defaultColors)]
		}
		emoji := opt.Emoji
		if emoji == "" {
			emoji = defaultEmojis[i%len(defaultEmojis)]
		}
		options[i] = models.Option{
			ID:    optID,
			Text:  strings.TrimSpace(opt.Text),
			Color: color,
			Emoji: emoji,
		}
	}

	poll := models.Poll{
		ID:           pollID,
		Title:        strings.TrimSpace(req.Title),
		Description:  strings.TrimSpace(req.Description),
		Options:      options,
		Settings:     req.Settings,
		IsClosed:     false,
		CreatorToken: creatorToken,
		CreatedAt:    now,
		UpdatedAt:    now,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// 1. Save poll to MongoDB
	_, err := h.Mongo.Database.Collection("polls").InsertOne(ctx, poll)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create poll in MongoDB: " + err.Error()})
		return
	}

	// 2. Return created poll with creatorToken
	c.JSON(http.StatusCreated, gin.H{
		"poll":         poll,
		"creatorToken": creatorToken,
	})
}

// GetPoll retrieves poll metadata and hydrates with real-time Redis vote counts
func (h *PollHandler) GetPoll(c *gin.Context) {
	pollID := c.Param("id")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var poll models.Poll
	err := h.Mongo.Database.Collection("polls").FindOne(ctx, bson.M{"id": pollID}).Decode(&poll)
	if err != nil {
		if err == mongo.ErrNoDocuments {
			c.JSON(http.StatusNotFound, gin.H{"error": "Poll not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Database error: " + err.Error()})
		return
	}

	// Fetch real-time counts from Redis
	votesMap, totalVotes, err := h.Redis.GetVotes(ctx, pollID)
	if err != nil {
		votesMap = make(map[string]int64)
	}
	totalVoters, _ := h.Redis.GetTotalVoters(ctx, pollID)

	// Merge counts
	for i := range poll.Options {
		poll.Options[i].VoteCount = votesMap[poll.Options[i].ID]
	}
	poll.TotalVotes = totalVotes
	poll.TotalVoters = totalVoters

	// Mask creator token if caller is not the creator
	clientCreatorToken := c.GetHeader("X-Creator-Token")
	if clientCreatorToken == "" || clientCreatorToken != poll.CreatorToken {
		poll.CreatorToken = ""
	}

	// Check expiry
	if poll.Settings.ExpiresAt != nil && time.Now().UTC().After(*poll.Settings.ExpiresAt) {
		poll.IsClosed = true
	}

	c.JSON(http.StatusOK, gin.H{"poll": poll})
}

// SubmitVote handles audience voting
func (h *PollHandler) SubmitVote(c *gin.Context) {
	pollID := c.Param("id")
	var req models.VoteRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request: " + err.Error()})
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// 1. Fetch poll to validate options and status
	var poll models.Poll
	err := h.Mongo.Database.Collection("polls").FindOne(ctx, bson.M{"id": pollID}).Decode(&poll)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Poll not found"})
		return
	}

	// Validate status
	if poll.IsClosed || (poll.Settings.ExpiresAt != nil && time.Now().UTC().After(*poll.Settings.ExpiresAt)) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "This poll is closed and no longer accepting votes"})
		return
	}

	// Check multiple options constraint
	if !poll.Settings.AllowMultiple && len(req.OptionIDs) > 1 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Multiple options are not allowed for this poll"})
		return
	}

	// Validate that selected options exist
	validOptionMap := make(map[string]bool)
	for _, opt := range poll.Options {
		validOptionMap[opt.ID] = true
	}
	for _, optID := range req.OptionIDs {
		if !validOptionMap[optID] {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid option selected: " + optID})
			return
		}
	}

	// 2. Check for duplicate vote using Redis set
	hasVoted, err := h.Redis.HasVoted(ctx, pollID, req.VoterID)
	if err == nil && hasVoted {
		c.JSON(http.StatusConflict, gin.H{"error": "You have already voted in this poll"})
		return
	}

	// 3. Atomically increment Redis counters for each selected option
	for _, optID := range req.OptionIDs {
		_, err := h.Redis.IncrementVote(ctx, pollID, optID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to record vote in Redis: " + err.Error()})
			return
		}
	}

	// Record voter in Redis set
	_ = h.Redis.RecordVoter(ctx, pollID, req.VoterID)

	// Fetch fresh counts from Redis
	updatedVotes, totalVotes, _ := h.Redis.GetVotes(ctx, pollID)
	totalVoters, _ := h.Redis.GetTotalVoters(ctx, pollID)

	// 4. Asynchronously persist vote record to MongoDB for audit / cold storage
	go func() {
		bgCtx, bgCancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer bgCancel()

		ip := c.ClientIP()
		hasher := sha256.New()
		hasher.Write([]byte(ip))
		ipHash := hex.EncodeToString(hasher.Sum(nil))[:16]

		voteRecord := models.VoteRecord{
			ID:        uuid.New().String(),
			PollID:    pollID,
			VoterID:   req.VoterID,
			VoterName: strings.TrimSpace(req.VoterName),
			OptionIDs: req.OptionIDs,
			IPHash:    ipHash,
			UserAgent: c.GetHeader("User-Agent"),
			CreatedAt: time.Now().UTC(),
		}
		_, _ = h.Mongo.Database.Collection("votes").InsertOne(bgCtx, voteRecord)
	}()

	// 5. Broadcast real-time update to all viewers via Redis Pub/Sub
	go func() {
		bgCtx, bgCancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer bgCancel()

		msg := models.RealtimeMessage{
			Type:   "vote_update",
			PollID: pollID,
			Data: models.VoteUpdatePayload{
				Votes:         updatedVotes,
				TotalVotes:    totalVotes,
				TotalVoters:   totalVoters,
				LastOptionIDs: req.OptionIDs,
			},
			Timestamp: time.Now().UnixMilli(),
		}
		bytes, _ := json.Marshal(msg)
		_ = h.Redis.PublishEvent(bgCtx, pollID, bytes)
	}()

	c.JSON(http.StatusOK, gin.H{
		"success":     true,
		"votes":       updatedVotes,
		"totalVotes":  totalVotes,
		"totalVoters": totalVoters,
	})
}

// SendReaction broadcasts a live emoji reaction from a viewer
func (h *PollHandler) SendReaction(c *gin.Context) {
	pollID := c.Param("id")
	var req models.ReactionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid reaction"})
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	reactionMsg := models.RealtimeMessage{
		Type:   "reaction",
		PollID: pollID,
		Data: models.ReactionPayload{
			ID:    uuid.New().String(),
			Emoji: req.Emoji,
		},
		Timestamp: time.Now().UnixMilli(),
	}

	bytes, _ := json.Marshal(reactionMsg)
	_ = h.Redis.PublishEvent(ctx, pollID, bytes)

	c.JSON(http.StatusOK, gin.H{"success": true})
}

// ToggleState opens or closes voting (creator only)
func (h *PollHandler) ToggleState(c *gin.Context) {
	pollID := c.Param("id")
	var req models.ToggleStateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request: " + err.Error()})
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Verify creator token
	var poll models.Poll
	err := h.Mongo.Database.Collection("polls").FindOne(ctx, bson.M{"id": pollID}).Decode(&poll)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Poll not found"})
		return
	}

	if poll.CreatorToken != req.CreatorToken {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid creator token"})
		return
	}

	// Update MongoDB
	_, err = h.Mongo.Database.Collection("polls").UpdateOne(
		ctx,
		bson.M{"id": pollID},
		bson.M{"$set": bson.M{
			"isClosed":  req.IsClosed,
			"updatedAt": time.Now().UTC(),
		}},
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update poll state"})
		return
	}

	// Broadcast state change
	go func() {
		bgCtx, bgCancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer bgCancel()

		msg := models.RealtimeMessage{
			Type:   "state_change",
			PollID: pollID,
			Data: models.StatePayload{
				IsClosed: req.IsClosed,
			},
			Timestamp: time.Now().UnixMilli(),
		}
		bytes, _ := json.Marshal(msg)
		_ = h.Redis.PublishEvent(bgCtx, pollID, bytes)
	}()

	c.JSON(http.StatusOK, gin.H{
		"success":  true,
		"isClosed": req.IsClosed,
	})
}

// ResetPoll clears votes in both Redis and MongoDB (creator only)
func (h *PollHandler) ResetPoll(c *gin.Context) {
	pollID := c.Param("id")
	var req models.ResetPollRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request: " + err.Error()})
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var poll models.Poll
	err := h.Mongo.Database.Collection("polls").FindOne(ctx, bson.M{"id": pollID}).Decode(&poll)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Poll not found"})
		return
	}

	if poll.CreatorToken != req.CreatorToken {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid creator token"})
		return
	}

	// 1. Reset Redis counters & voter set
	_ = h.Redis.ResetPoll(ctx, pollID)

	// 2. Delete votes from MongoDB
	_, _ = h.Mongo.Database.Collection("votes").DeleteMany(ctx, bson.M{"pollId": pollID})

	// 3. Broadcast vote_update with 0s
	emptyVotes := make(map[string]int64)
	for _, opt := range poll.Options {
		emptyVotes[opt.ID] = 0
	}

	go func() {
		bgCtx, bgCancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer bgCancel()

		msg := models.RealtimeMessage{
			Type:   "vote_update",
			PollID: pollID,
			Data: models.VoteUpdatePayload{
				Votes:       emptyVotes,
				TotalVotes:  0,
				TotalVoters: 0,
			},
			Timestamp: time.Now().UnixMilli(),
		}
		bytes, _ := json.Marshal(msg)
		_ = h.Redis.PublishEvent(bgCtx, pollID, bytes)
	}()

	c.JSON(http.StatusOK, gin.H{"success": true, "message": "Poll reset successfully"})
}

// ExportVotes exports voting data (creator only)
func (h *PollHandler) ExportVotes(c *gin.Context) {
	pollID := c.Param("id")
	token := c.Query("token")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var poll models.Poll
	err := h.Mongo.Database.Collection("polls").FindOne(ctx, bson.M{"id": pollID}).Decode(&poll)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Poll not found"})
		return
	}

	if poll.CreatorToken != token {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
		return
	}

	cursor, err := h.Mongo.Database.Collection("votes").Find(ctx, bson.M{"pollId": pollID})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to query votes"})
		return
	}
	defer cursor.Close(ctx)

	var votes []models.VoteRecord
	if err := cursor.All(ctx, &votes); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to decode votes"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"poll":  poll,
		"votes": votes,
	})
}

// HealthCheck checks connectivity to MongoDB and Redis
func (h *PollHandler) HealthCheck(c *gin.Context) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	mongoStatus := "connected"
	if err := h.Mongo.Client.Ping(ctx, nil); err != nil {
		mongoStatus = "error: " + err.Error()
	}

	redisStatus := "connected"
	if err := h.Redis.Client.Ping(ctx).Err(); err != nil {
		redisStatus = "error: " + err.Error()
	}

	c.JSON(http.StatusOK, gin.H{
		"status":  "healthy",
		"mongodb": mongoStatus,
		"redis":   redisStatus,
		"time":    time.Now().UTC(),
	})
}
