package handlers

import (
	"github.com/gin-gonic/gin"
	"pulsepoll-backend/internal/realtime"
)

type WSHandler struct {
	Hub *realtime.Hub
}

func NewWSHandler(hub *realtime.Hub) *WSHandler {
	return &WSHandler{Hub: hub}
}

func (h *WSHandler) HandlePollWS(c *gin.Context) {
	pollID := c.Param("id")
	if pollID == "" {
		return
	}
	h.Hub.ServeWS(c.Writer, c.Request, pollID)
}
