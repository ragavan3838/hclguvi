package config

import (
	"os"
)

type Config struct {
	Port          string
	MongoURI      string
	DatabaseName  string
	RedisAddr     string
	RedisPassword string
	ClientOrigin  string
}

func LoadConfig() *Config {
	port := getEnv("PORT", "8080")
	mongoURI := getEnv("MONGO_URI", "mongodb://localhost:27017")
	dbName := getEnv("DB_NAME", "live_polling")
	redisAddr := getEnv("REDIS_ADDR", "localhost:6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	clientOrigin := getEnv("CLIENT_ORIGIN", "*")

	return &Config{
		Port:          port,
		MongoURI:      mongoURI,
		DatabaseName:  dbName,
		RedisAddr:     redisAddr,
		RedisPassword: redisPassword,
		ClientOrigin:  clientOrigin,
	}
}

func getEnv(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}
