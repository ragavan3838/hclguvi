package database

import (
	"context"
	"fmt"
	"log"
	"strconv"
	"time"

	"github.com/redis/go-redis/v9"
)

type RedisClient struct {
	Client *redis.Client
}

func ConnectRedis(addr, password string) (*RedisClient, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       0,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := rdb.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("failed to connect to Redis at %s: %w", addr, err)
	}

	log.Println("[Redis] Connected successfully to:", addr)
	return &RedisClient{Client: rdb}, nil
}

func (r *RedisClient) Close() {
	if r.Client != nil {
		_ = r.Client.Close()
		log.Println("[Redis] Connection closed")
	}
}

// Redis keys formatting
func PollVotesKey(pollId string) string {
	return fmt.Sprintf("poll:%s:votes", pollId)
}

func PollVotersKey(pollId string) string {
	return fmt.Sprintf("poll:%s:voters", pollId)
}

func PollChannel(pollId string) string {
	return fmt.Sprintf("channel:poll:%s", pollId)
}

func PollViewersKey(pollId string) string {
	return fmt.Sprintf("poll:%s:viewers", pollId)
}

// IncrementVote increments the vote count for a specific option atomically
func (r *RedisClient) IncrementVote(ctx context.Context, pollId, optionId string) (int64, error) {
	return r.Client.HIncrBy(ctx, PollVotesKey(pollId), optionId, 1).Result()
}

// HasVoted checks if the voter has already voted in this poll
func (r *RedisClient) HasVoted(ctx context.Context, pollId, voterId string) (bool, error) {
	return r.Client.SIsMember(ctx, PollVotersKey(pollId), voterId).Result()
}

// RecordVoter registers that a voter has participated
func (r *RedisClient) RecordVoter(ctx context.Context, pollId, voterId string) error {
	return r.Client.SAdd(ctx, PollVotersKey(pollId), voterId).Err()
}

// GetVotes retrieves all option counts for a poll from Redis
func (r *RedisClient) GetVotes(ctx context.Context, pollId string) (map[string]int64, int64, error) {
	data, err := r.Client.HGetAll(ctx, PollVotesKey(pollId)).Result()
	if err != nil {
		return nil, 0, err
	}

	res := make(map[string]int64)
	var total int64
	for optId, countStr := range data {
		count, _ := strconv.ParseInt(countStr, 10, 64)
		res[optId] = count
		total += count
	}

	return res, total, nil
}

// GetTotalVoters gets the number of unique voters from the Redis set
func (r *RedisClient) GetTotalVoters(ctx context.Context, pollId string) (int64, error) {
	return r.Client.SCard(ctx, PollVotersKey(pollId)).Result()
}

// ResetPoll clears Redis votes and voter tracking for a poll
func (r *RedisClient) ResetPoll(ctx context.Context, pollId string) error {
	pipe := r.Client.Pipeline()
	pipe.Del(ctx, PollVotesKey(pollId))
	pipe.Del(ctx, PollVotersKey(pollId))
	_, err := pipe.Exec(ctx)
	return err
}

// PublishEvent publishes a message onto the poll's pub/sub channel
func (r *RedisClient) PublishEvent(ctx context.Context, pollId string, message []byte) error {
	return r.Client.Publish(ctx, PollChannel(pollId), message).Err()
}

// AddViewer tracks active viewer
func (r *RedisClient) AddViewer(ctx context.Context, pollId, clientId string) (int64, error) {
	key := PollViewersKey(pollId)
	pipe := r.Client.Pipeline()
	pipe.SAdd(ctx, key, clientId)
	pipe.Expire(ctx, key, 1*time.Hour)
	scard := pipe.SCard(ctx, key)
	_, err := pipe.Exec(ctx)
	if err != nil {
		return 0, err
	}
	return scard.Val(), nil
}

// RemoveViewer untracks viewer
func (r *RedisClient) RemoveViewer(ctx context.Context, pollId, clientId string) (int64, error) {
	key := PollViewersKey(pollId)
	pipe := r.Client.Pipeline()
	pipe.SRem(ctx, key, clientId)
	scard := pipe.SCard(ctx, key)
	_, err := pipe.Exec(ctx)
	if err != nil {
		return 0, err
	}
	return scard.Val(), nil
}

// GetViewersCount gets active viewer count
func (r *RedisClient) GetViewersCount(ctx context.Context, pollId string) (int64, error) {
	return r.Client.SCard(ctx, PollViewersKey(pollId)).Result()
}
