package models

import (
	"time"
)

type Option struct {
	ID        string `bson:"id" json:"id"`
	Text      string `bson:"text" json:"text" binding:"required"`
	Color     string `bson:"color" json:"color"`
	Emoji     string `bson:"emoji" json:"emoji"`
	VoteCount int64  `bson:"-" json:"voteCount"`
}

type PollSettings struct {
	AllowMultiple        bool       `bson:"allowMultiple" json:"allowMultiple"`
	RequireName          bool       `bson:"requireName" json:"requireName"`
	ShowResultsImmediate bool       `bson:"showResultsImmediate" json:"showResultsImmediate"`
	ExpiresAt            *time.Time `bson:"expiresAt,omitempty" json:"expiresAt,omitempty"`
}

type Poll struct {
	ID           string       `bson:"id" json:"id"`
	Title        string       `bson:"title" json:"title" binding:"required"`
	Description  string       `bson:"description" json:"description"`
	Options      []Option     `bson:"options" json:"options" binding:"required,min=2"`
	Settings     PollSettings `bson:"settings" json:"settings"`
	IsClosed     bool         `bson:"isClosed" json:"isClosed"`
	CreatorToken string       `bson:"creatorToken" json:"creatorToken,omitempty"`
	TotalVotes   int64        `bson:"-" json:"totalVotes"`
	TotalVoters  int64        `bson:"-" json:"totalVoters"`
	CreatedAt    time.Time    `bson:"createdAt" json:"createdAt"`
	UpdatedAt    time.Time    `bson:"updatedAt" json:"updatedAt"`
}

type CreatePollRequest struct {
	Title       string       `json:"title" binding:"required"`
	Description string       `json:"description"`
	Options     []Option     `json:"options" binding:"required,min=2"`
	Settings    PollSettings `json:"settings"`
}

type VoteRequest struct {
	VoterID   string   `json:"voterId" binding:"required"`
	VoterName string   `json:"voterName"`
	OptionIDs []string `json:"optionIds" binding:"required,min=1"`
}

type VoteRecord struct {
	ID        string    `bson:"_id,omitempty" json:"id"`
	PollID    string    `bson:"pollId" json:"pollId"`
	VoterID   string    `bson:"voterId" json:"voterId"`
	VoterName string    `bson:"voterName,omitempty" json:"voterName,omitempty"`
	OptionIDs []string  `bson:"optionIds" json:"optionIds"`
	IPHash    string    `bson:"ipHash" json:"ipHash"`
	UserAgent string    `bson:"userAgent" json:"userAgent"`
	CreatedAt time.Time `bson:"createdAt" json:"createdAt"`
}

type ReactionRequest struct {
	Emoji string `json:"emoji" binding:"required"`
}

type ToggleStateRequest struct {
	CreatorToken string `json:"creatorToken" binding:"required"`
	IsClosed     bool   `json:"isClosed"`
}

type ResetPollRequest struct {
	CreatorToken string `json:"creatorToken" binding:"required"`
}

type RealtimeMessage struct {
	Type      string      `json:"type"`
	PollID    string      `json:"pollId"`
	Data      interface{} `json:"data"`
	Timestamp int64       `json:"timestamp"`
}

type VoteUpdatePayload struct {
	Votes         map[string]int64 `json:"votes"`
	TotalVotes    int64            `json:"totalVotes"`
	TotalVoters   int64            `json:"totalVoters"`
	LastOptionIDs []string         `json:"lastOptionIds,omitempty"`
}

type ReactionPayload struct {
	ID    string `json:"id"`
	Emoji string `json:"emoji"`
}

type ViewersPayload struct {
	Count int64 `json:"count"`
}

type StatePayload struct {
	IsClosed bool `json:"isClosed"`
}
